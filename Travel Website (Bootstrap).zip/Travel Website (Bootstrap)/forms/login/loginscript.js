$("#form").mouseleave(function() {closeForm();})

function openForm() {
    $("#form").css("transform", "translate(0)");
}
function closeForm() {
    $("#form").css("transform", "translate(1000px)");
}









